package com.example.exp4regform;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    String[] subj= {"Mobile computing", "Android Development", "Digital Marketing", "Fibre Optics"};

    Spinner spinnerSubject;
    RadioGroup rad;


    CheckBox checkBoxSSC, checkBoxHSC, checkBoxBachelor, checkBoxMaster;


    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);


        spinnerSubject = findViewById(R.id.spinner);
        rad=findViewById(R.id.radiogroup);

        checkBoxSSC = findViewById(R.id.checkboxssc);

        checkBoxHSC = findViewById(R.id.checkboxhsc);

        checkBoxBachelor = findViewById(R.id.checkboxbachelor);

        checkBoxMaster = findViewById(R.id.checkboxmaster);




        // Set up the spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<>(MainActivity.this,

                android.R.layout.simple_spinner_item, subj);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinnerSubject.setAdapter(adapter);
        spinnerSubject.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String text=adapterView.getItemAtPosition(i).toString();
                Toast.makeText(adapterView.getContext(),text,Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }

        });
    }
}