package com.example.myapppopup;

import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.BaseAdapter;
public class MyListAdapter extends BaseAdapter {

    private String[] mData;

    public MyListAdapter(String[] data) {
        mData = data;
    }

    @Override
    public int getCount() {
        return mData.length;
    }

    @Override
    public Object getItem(int position) {
        return mData[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        TextView view;

        if (convertView == null) {
            view = new TextView(parent.getContext());
        } else {
            view = (TextView) convertView;
        }

        view.setText(mData[position]);
        return view;
    }

}